.net api class foreign key
.net connection string
