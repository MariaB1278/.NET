﻿namespace FinalAPI.Models
{
    public class CustomerDTO
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PID { get; set; }
    }
}
